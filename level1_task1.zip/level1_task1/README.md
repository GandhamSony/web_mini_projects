# Simple HTML/CSS Examples

This project contains three simple HTML/CSS examples as requested:

## Files

1. **webpage.html**: A simple webpage with a heading, paragraph, and an image.
2. **form.html**: A basic form with a single input field and a submit button.
3. **nav.html**: A simple navigation menu with three links.

## How to View

Open each HTML file in a web browser to see the results. No server is required as these are static HTML pages.

## Usage

- **webpage.html**: Displays a centered heading, paragraph, and a placeholder image.
- **form.html**: Contains a form with a text input for name and a submit button. The form action is set to "#" so it doesn't submit anywhere.
- **nav.html**: Shows a horizontal navigation bar with three links (Home, About, Contact) that link to anchors on the same page.

## Styling

Each page uses inline CSS for simplicity. The styles include basic layout, colors, and hover effects where appropriate.
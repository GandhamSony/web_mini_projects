// Form validation and handling
const contactForm = document.getElementById('contact-form');
const successMessage = document.createElement('div');
successMessage.className = 'success-message';
successMessage.textContent = 'Thank you! Your message has been sent successfully.';
contactForm.parentNode.insertBefore(successMessage, contactForm);

// Custom validation functions
function validateName(name) {
    if (name.trim().length < 2) {
        return 'Name must be at least 2 characters long.';
    }
    if (!/^[a-zA-Z\s]+$/.test(name.trim())) {
        return 'Name can only contain letters and spaces.';
    }
    return '';
}

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        return 'Please enter a valid email address.';
    }
    return '';
}

function validatePhone(phone) {
    if (phone && !/^\d{3}-\d{3}-\d{4}$/.test(phone)) {
        return 'Phone number must be in the format 123-456-7890.';
    }
    return '';
}

function validateMessage(message) {
    if (message.trim().length < 10) {
        return 'Message must be at least 10 characters long.';
    }
    return '';
}

// Real-time validation
const inputs = document.querySelectorAll('input, select, textarea');
inputs.forEach(input => {
    input.addEventListener('blur', function() {
        validateField(this);
    });

    input.addEventListener('input', function() {
        if (this.classList.contains('invalid')) {
            validateField(this);
        }
    });
});

function validateField(field) {
    const errorElement = document.getElementById(field.id + '-error');
    let errorMessage = '';

    switch (field.id) {
        case 'name':
            errorMessage = validateName(field.value);
            break;
        case 'email':
            errorMessage = validateEmail(field.value);
            break;
        case 'phone':
            errorMessage = validatePhone(field.value);
            break;
        case 'message':
            errorMessage = validateMessage(field.value);
            break;
        case 'subject':
            if (!field.value) {
                errorMessage = 'Please select a subject.';
            }
            break;
    }

    if (errorMessage) {
        errorElement.textContent = errorMessage;
        field.classList.add('invalid');
        field.classList.remove('valid');
    } else {
        errorElement.textContent = '';
        field.classList.remove('invalid');
        field.classList.add('valid');
    }
}

// Form submission
contactForm.addEventListener('submit', function(e) {
    e.preventDefault();

    // Validate all fields
    let isValid = true;
    inputs.forEach(input => {
        if (input.hasAttribute('required') || input.value) {
            validateField(input);
            if (input.classList.contains('invalid')) {
                isValid = false;
            }
        }
    });

    // Check radio buttons
    const contactMethod = document.querySelector('input[name="contact-method"]:checked');
    if (!contactMethod) {
        document.getElementById('contact-method-error').textContent = 'Please select a contact method.';
        isValid = false;
    } else {
        document.getElementById('contact-method-error').textContent = '';
    }

    if (isValid) {
        // Simulate form submission
        console.log('Form submitted successfully!');
        console.log('Form data:', new FormData(contactForm));

        // Show success message
        successMessage.style.display = 'block';

        // Reset form
        contactForm.reset();

        // Clear validation classes
        inputs.forEach(input => {
            input.classList.remove('valid', 'invalid');
        });

        // Scroll to top
        window.scrollTo({ top: 0, behavior: 'smooth' });

        // Hide success message after 5 seconds
        setTimeout(() => {
            successMessage.style.display = 'none';
        }, 5000);
    } else {
        // Scroll to first error
        const firstError = document.querySelector('.error-message:not(:empty)');
        if (firstError) {
            firstError.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }
    }
});

// Phone number formatting
const phoneInput = document.getElementById('phone');
phoneInput.addEventListener('input', function(e) {
    let value = e.target.value.replace(/\D/g, '');
    if (value.length >= 6) {
        value = value.slice(0, 3) + '-' + value.slice(3, 6) + '-' + value.slice(6, 10);
    } else if (value.length >= 3) {
        value = value.slice(0, 3) + '-' + value.slice(3);
    }
    e.target.value = value;
});

// Character counter for textarea
const messageTextarea = document.getElementById('message');
const charCounter = document.createElement('div');
charCounter.style.fontSize = '0.875rem';
charCounter.style.color = '#666';
charCounter.style.marginTop = '0.25rem';
messageTextarea.parentNode.appendChild(charCounter);

messageTextarea.addEventListener('input', function() {
    const remaining = 500 - this.value.length;
    charCounter.textContent = `${remaining} characters remaining`;
    if (remaining < 0) {
        charCounter.style.color = '#dc3545';
    } else {
        charCounter.style.color = '#666';
    }
});

// Initialize character counter
messageTextarea.dispatchEvent(new Event('input'));
// Task Manager Application
class TaskManager {
    constructor() {
        this.tasks = JSON.parse(localStorage.getItem('tasks')) || [];
        this.currentFilter = 'all';
        this.draggedElement = null;

        this.init();
    }

    init() {
        this.bindEvents();
        this.renderTasks();
        this.updateStats();
        this.setDefaultDueDate();
    }

    bindEvents() {
        // Add task form
        document.getElementById('add-task-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.addTask();
        });

        // Filter buttons
        document.getElementById('filter-all').addEventListener('click', () => this.setFilter('all'));
        document.getElementById('filter-active').addEventListener('click', () => this.setFilter('active'));
        document.getElementById('filter-completed').addEventListener('click', () => this.setFilter('completed'));

        // Clear completed
        document.getElementById('clear-completed').addEventListener('click', () => this.clearCompleted());

        // Edit modal
        document.getElementById('edit-task-form').addEventListener('submit', (e) => {
            e.preventDefault();
            this.saveEditedTask();
        });
        document.getElementById('cancel-edit').addEventListener('click', () => this.closeEditModal());

        // Search functionality
        document.getElementById('search-input').addEventListener('input', (e) => this.searchTasks(e.target.value));

        // Close modal when clicking outside
        document.getElementById('edit-modal').addEventListener('click', (e) => {
            if (e.target.id === 'edit-modal') {
                this.closeEditModal();
            }
        });
    }

    addTask() {
        const input = document.getElementById('task-input');
        const priority = document.getElementById('priority-select').value;
        const dueDate = document.getElementById('due-date-input').value;

        if (input.value.trim() === '') return;

        const task = {
            id: Date.now(),
            text: input.value.trim(),
            completed: false,
            priority: priority,
            dueDate: dueDate,
            createdAt: new Date().toISOString()
        };

        this.tasks.unshift(task);
        this.saveTasks();
        this.renderTasks();
        this.updateStats();

        input.value = '';
        this.setDefaultDueDate();

        this.showNotification('Task added successfully!');
    }

    renderTasks() {
        const taskList = document.getElementById('task-list');
        const emptyState = document.getElementById('empty-state');

        let filteredTasks = this.tasks;

        if (this.currentFilter === 'active') {
            filteredTasks = this.tasks.filter(task => !task.completed);
        } else if (this.currentFilter === 'completed') {
            filteredTasks = this.tasks.filter(task => task.completed);
        }

        if (document.getElementById('search-input').value) {
            const searchTerm = document.getElementById('search-input').value.toLowerCase();
            filteredTasks = filteredTasks.filter(task =>
                task.text.toLowerCase().includes(searchTerm)
            );
        }

        taskList.innerHTML = '';

        if (filteredTasks.length === 0) {
            emptyState.style.display = 'block';
        } else {
            emptyState.style.display = 'none';
            filteredTasks.forEach(task => {
                const taskElement = this.createTaskElement(task);
                taskList.appendChild(taskElement);
            });
        }
    }

    createTaskElement(task) {
        const taskItem = document.createElement('div');
        taskItem.className = `task-item ${task.completed ? 'completed' : ''}`;
        taskItem.draggable = true;
        taskItem.dataset.id = task.id;

        const dueDateText = task.dueDate ? new Date(task.dueDate).toLocaleDateString() : 'No due date';
        const isOverdue = task.dueDate && !task.completed && new Date(task.dueDate) < new Date();

        taskItem.innerHTML = `
            <input type="checkbox" class="task-checkbox" ${task.completed ? 'checked' : ''}>
            <div class="task-content">
                <div class="task-text">${this.escapeHtml(task.text)}</div>
                <div class="task-meta">
                    <span class="task-priority ${task.priority}">${task.priority}</span>
                    <span>Due: ${dueDateText}</span>
                    ${isOverdue ? '<span style="color: #dc3545; font-weight: bold;">OVERDUE</span>' : ''}
                </div>
            </div>
            <div class="task-actions">
                <button class="task-btn edit-btn">Edit</button>
                <button class="task-btn delete-btn">Delete</button>
            </div>
        `;

        // Bind events
        const checkbox = taskItem.querySelector('.task-checkbox');
        const editBtn = taskItem.querySelector('.edit-btn');
        const deleteBtn = taskItem.querySelector('.delete-btn');

        checkbox.addEventListener('change', () => this.toggleTask(task.id));
        editBtn.addEventListener('click', () => this.openEditModal(task));
        deleteBtn.addEventListener('click', () => this.deleteTask(task.id));

        // Drag and drop
        taskItem.addEventListener('dragstart', (e) => this.handleDragStart(e, task.id));
        taskItem.addEventListener('dragend', () => this.handleDragEnd());
        taskItem.addEventListener('dragover', (e) => this.handleDragOver(e));
        taskItem.addEventListener('drop', (e) => this.handleDrop(e, task.id));

        return taskItem;
    }

    toggleTask(id) {
        const task = this.tasks.find(t => t.id === id);
        if (task) {
            task.completed = !task.completed;
            this.saveTasks();
            this.renderTasks();
            this.updateStats();
            this.showNotification(task.completed ? 'Task completed!' : 'Task marked as active');
        }
    }

    openEditModal(task) {
        this.editingTaskId = task.id;
        document.getElementById('edit-task-input').value = task.text;
        document.getElementById('edit-priority-select').value = task.priority;
        document.getElementById('edit-due-date-input').value = task.dueDate || '';
        document.getElementById('edit-modal').style.display = 'block';
    }

    closeEditModal() {
        document.getElementById('edit-modal').style.display = 'none';
        this.editingTaskId = null;
    }

    saveEditedTask() {
        const newText = document.getElementById('edit-task-input').value.trim();
        const newPriority = document.getElementById('edit-priority-select').value;
        const newDueDate = document.getElementById('edit-due-date-input').value;

        if (newText === '') return;

        const task = this.tasks.find(t => t.id === this.editingTaskId);
        if (task) {
            task.text = newText;
            task.priority = newPriority;
            task.dueDate = newDueDate;
            this.saveTasks();
            this.renderTasks();
            this.closeEditModal();
            this.showNotification('Task updated successfully!');
        }
    }

    deleteTask(id) {
        if (confirm('Are you sure you want to delete this task?')) {
            this.tasks = this.tasks.filter(t => t.id !== id);
            this.saveTasks();
            this.renderTasks();
            this.updateStats();
            this.showNotification('Task deleted');
        }
    }

    setFilter(filter) {
        this.currentFilter = filter;
        document.querySelectorAll('.filter-btn').forEach(btn => btn.classList.remove('active'));
        document.getElementById(`filter-${filter}`).classList.add('active');
        this.renderTasks();
    }

    clearCompleted() {
        if (confirm('Are you sure you want to clear all completed tasks?')) {
            this.tasks = this.tasks.filter(t => !t.completed);
            this.saveTasks();
            this.renderTasks();
            this.updateStats();
            this.showNotification('Completed tasks cleared');
        }
    }

    searchTasks(query) {
        this.renderTasks();
    }

    updateStats() {
        const total = this.tasks.length;
        const active = this.tasks.filter(t => !t.completed).length;
        const completed = this.tasks.filter(t => t.completed).length;

        document.getElementById('total-tasks').textContent = total;
        document.getElementById('active-tasks').textContent = active;
        document.getElementById('completed-tasks').textContent = completed;
    }

    setDefaultDueDate() {
        const tomorrow = new Date();
        tomorrow.setDate(tomorrow.getDate() + 1);
        document.getElementById('due-date-input').value = tomorrow.toISOString().split('T')[0];
    }

    // Drag and Drop functionality
    handleDragStart(e, id) {
        this.draggedElement = e.target;
        e.target.classList.add('dragging');
        e.dataTransfer.effectAllowed = 'move';
        e.dataTransfer.setData('text/html', e.target.outerHTML);
    }

    handleDragEnd() {
        if (this.draggedElement) {
            this.draggedElement.classList.remove('dragging');
            this.draggedElement = null;
        }
    }

    handleDragOver(e) {
        e.preventDefault();
        e.dataTransfer.dropEffect = 'move';
        return false;
    }

    handleDrop(e, targetId) {
        e.preventDefault();

        const draggedId = parseInt(this.draggedElement.dataset.id);
        const targetIndex = this.tasks.findIndex(t => t.id === targetId);
        const draggedIndex = this.tasks.findIndex(t => t.id === draggedId);

        if (draggedIndex !== -1 && targetIndex !== -1 && draggedIndex !== targetIndex) {
            const draggedTask = this.tasks.splice(draggedIndex, 1)[0];
            this.tasks.splice(targetIndex, 0, draggedTask);
            this.saveTasks();
            this.renderTasks();
        }
    }

    saveTasks() {
        localStorage.setItem('tasks', JSON.stringify(this.tasks));
    }

    showNotification(message) {
        const notification = document.getElementById('notification');
        const notificationText = document.getElementById('notification-text');

        notificationText.textContent = message;
        notification.classList.add('show');

        setTimeout(() => {
            notification.classList.remove('show');
        }, 3000);
    }

    escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
}

// Initialize the application
document.addEventListener('DOMContentLoaded', () => {
    new TaskManager();
});